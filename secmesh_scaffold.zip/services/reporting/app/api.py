from __future__ import annotations

import io, os, json
from fastapi import APIRouter, Response, HTTPException
from jsonschema import Draft202012Validator

from secmesh_common.models import AssessmentReport
from app.pdf_renderer import render_report_pdf

router = APIRouter(prefix="/v1")

SCHEMA_PATH = os.getenv("SECMESH_REPORT_SCHEMA", "/schemas/report.schema.json")

def _validate_schema(payload: dict) -> None:
    if not os.path.exists(SCHEMA_PATH):
        raise HTTPException(status_code=500, detail=f"Report schema not found: {SCHEMA_PATH}")

    schema = json.loads(open(SCHEMA_PATH, "r", encoding="utf-8").read())
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(payload), key=lambda e: e.path)
    if errors:
        msg = "; ".join([f"{'/'.join([str(p) for p in e.path])}: {e.message}" for e in errors[:5]])
        raise HTTPException(status_code=400, detail=f"Schema validation failed: {msg}")

@router.post("/report/validate")
def validate_report(report: AssessmentReport):
    _validate_schema(report.model_dump())
    return {"valid": True}

@router.post("/report/pdf")
def report_pdf(report: AssessmentReport):
    _validate_schema(report.model_dump())
    buf = io.BytesIO()
    render_report_pdf(report.model_dump(), buf)
    return Response(content=buf.getvalue(), media_type="application/pdf")
