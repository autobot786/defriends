from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel, Field
from secmesh_common.models import VulnerabilityFinding

router = APIRouter(prefix="/v1")

class ScoreRequest(BaseModel):
    findings: list[VulnerabilityFinding] = Field(default_factory=list)

class ScoredFinding(BaseModel):
    cve: str
    risk_score: float
    priority: str

class ScoreResponse(BaseModel):
    overall_risk_score: float
    scored: list[ScoredFinding]

def _priority(score: float) -> str:
    if score >= 85:
        return "p0"
    if score >= 70:
        return "p1"
    if score >= 50:
        return "p2"
    return "p3"

@router.post("/score", response_model=ScoreResponse)
def score(req: ScoreRequest):
    scored: list[ScoredFinding] = []
    total = 0.0
    n = max(1, len(req.findings))

    for f in req.findings:
        cvss = float(f.cvss_v3 or 0.0)  # 0..10
        epss = float(f.epss or 0.0)     # 0..1
        kev = 1.0 if f.kev else 0.0
        reachable = 1.0 if f.exposure.reachable else 0.0
        internet = 1.0 if f.exposure.internet_facing else 0.0

        score = (
            (cvss / 10.0) * 55.0 +
            (epss) * 25.0 +
            kev * 10.0 +
            reachable * 7.0 +
            internet * 3.0
        )
        score = max(0.0, min(100.0, score))
        total += score

        scored.append(ScoredFinding(cve=f.cve, risk_score=round(score, 2), priority=_priority(score)))

    overall = round(total / n, 2)
    return ScoreResponse(overall_risk_score=overall, scored=scored)
