from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import re
import yaml

from secmesh_common.util import get_path
from secmesh_common.models import MitreTechnique

@dataclass(frozen=True)
class RulePack:
    pack_id: str
    version: str
    mitre_version: str
    rules: list[dict[str, Any]]

def load_rule_pack(path: str) -> RulePack:
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    meta = data.get("meta", {})
    return RulePack(
        pack_id=meta.get("pack_id", "unknown-pack"),
        version=meta.get("version", "0.0.0"),
        mitre_version=meta.get("mitre_version", "unknown"),
        rules=data.get("rules", []),
    )

def _match_value(op: str, left: Any, right: Any) -> bool:
    if op == "eq":
        return left == right
    if op == "neq":
        return left != right
    if op == "in":
        return left in (right or [])
    if op == "nin":
        return left not in (right or [])
    if op == "regex":
        if left is None:
            return False
        return re.search(str(right), str(left)) is not None
    if op == "truthy":
        return bool(left) is True
    if op == "falsy":
        return bool(left) is False
    raise ValueError(f"Unsupported op: {op}")

def rule_matches(rule: dict[str, Any], ctx: dict[str, Any]) -> bool:
    conds = rule.get("when", [])
    if not conds:
        return False

    def eval_cond(c: dict[str, Any]) -> bool:
        if "any" in c:
            return any(eval_cond(x) for x in c["any"])
        if "all" in c:
            return all(eval_cond(x) for x in c["all"])
        path = c.get("path")
        op = c.get("op", "eq")
        value = c.get("value")
        left = get_path(ctx, path, default=None)
        return _match_value(op, left, value)

    return all(eval_cond(c) for c in conds)

def apply_rules(pack: RulePack, ctx: dict[str, Any]) -> list[MitreTechnique]:
    techniques: list[MitreTechnique] = []
    for rule in pack.rules:
        if rule_matches(rule, ctx):
            then = rule.get("then", {})
            for t in then.get("techniques", []):
                techniques.append(MitreTechnique(
                    technique_id=t["id"],
                    technique_name=t["name"],
                    tactic=t["tactic"],
                    confidence=float(t.get("confidence", then.get("confidence", 0.6))),
                    rationale=then.get("rationale", "Matched rule."),
                ))

    dedup: dict[str, MitreTechnique] = {}
    for t in techniques:
        cur = dedup.get(t.technique_id)
        if cur is None or t.confidence > cur.confidence:
            dedup[t.technique_id] = t
    return sorted(dedup.values(), key=lambda x: (-x.confidence, x.technique_id))
