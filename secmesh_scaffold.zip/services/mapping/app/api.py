from __future__ import annotations

import os
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from secmesh_common.models import MitreTechnique
from app.rule_engine import load_rule_pack, apply_rules

router = APIRouter(prefix="/v1")

DEFAULT_PACK_PATH = os.getenv("SECMESH_MAPPING_PACK", "/rules/mapping/mitre_cwe_context.v1.yaml")

class MapRequest(BaseModel):
    cve: str | None = None
    cwe: str | None = None
    exposure: dict = Field(default_factory=dict)
    app: dict = Field(default_factory=dict)
    tags: list[str] = Field(default_factory=list)

class MapResponse(BaseModel):
    pack_id: str
    pack_version: str
    mitre_version: str
    techniques: list[MitreTechnique]

@router.post("/map", response_model=MapResponse)
def map_to_mitre(req: MapRequest):
    if not os.path.exists(DEFAULT_PACK_PATH):
        raise HTTPException(status_code=500, detail=f"Rule pack not found: {DEFAULT_PACK_PATH}")

    pack = load_rule_pack(DEFAULT_PACK_PATH)
    ctx = {"cve": req.cve, "cwe": req.cwe, "exposure": req.exposure, "app": req.app, "tags": req.tags}
    techniques = apply_rules(pack, ctx)

    return MapResponse(pack_id=pack.pack_id, pack_version=pack.version, mitre_version=pack.mitre_version, techniques=techniques)
