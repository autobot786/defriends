#!/usr/bin/env bash
set -euo pipefail
python reports/pdf/render_report.py examples/sample_report.json examples/sample_report.pdf
