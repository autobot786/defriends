# PDF layout notes (scaffold)

The sample renderer uses ReportLab (platypus) and aims for:
- Title page + summary tiles
- Findings table with MITRE technique summary
- Gap analysis table + prioritized recommendations

Edit typography and spacing in `reports/pdf/render_report.py`.
