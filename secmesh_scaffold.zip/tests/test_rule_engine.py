from __future__ import annotations
from services.mapping.app.rule_engine import load_rule_pack, apply_rules

def test_mapping_pack_load_and_apply():
    pack = load_rule_pack("rules/mapping/mitre_cwe_context.v1.yaml")
    ctx = {
        "cve": "CVE-2025-12345",
        "cwe": "CWE-502",
        "exposure": {"internet_facing": True, "reachable": True, "authenticated_required": False, "privilege_boundary": "none"},
        "app": {},
        "tags": [],
    }
    techniques = apply_rules(pack, ctx)
    assert any(t.technique_id == "T1190" for t in techniques)
